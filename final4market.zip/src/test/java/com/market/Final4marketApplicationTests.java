package com.market;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(classes = Final4marketApplication.class)
public class Final4marketApplicationTests {

    @Test
    void contextLoads() {
    }
}
